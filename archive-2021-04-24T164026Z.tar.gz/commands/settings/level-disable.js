module.exports = ({
  name: "level-disable",
  code: `$setServerVar[levelSYS;1]
Disabled level! `
})