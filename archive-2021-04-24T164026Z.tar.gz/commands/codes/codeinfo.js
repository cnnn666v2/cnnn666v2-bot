module.exports = ({
  name: "codes",
  code: `$color[RANDOM]
$title[Codes - bcoz why not?]
$description[**What are they?**
Codes are used to give things such as :pound: or items.
**Are they time limited?**
Some of them are, and some not :smile:
Avaible codes:]
$addField[Starter • \`$getServerVar[svpx6]code-starter\`;Duration: :infinity:
Description: gives you few :pound: and nCoin. Can be used only once;yes]`
})