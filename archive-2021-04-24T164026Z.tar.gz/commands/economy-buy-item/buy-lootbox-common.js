module.exports = ({
  name: "lootbox-buy-common",
  code: `$color[RANDOM]
$title[:tada: :tada: Congratualtions :tada: :tada:]
$description[$username bought common lootbox for 500 :pound:]
$footer[Goodluck! | Version: $getVar[version]] `
})