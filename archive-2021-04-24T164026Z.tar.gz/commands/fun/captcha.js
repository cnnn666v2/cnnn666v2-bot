//CAPTCHA
module.exports = ({
  name: "captcha",
  code: `By: $username
$image[https://api.cool-img-api.ml/captcha?text=$message] `
})