module.exports = ({
  name: "kill",
  code: `$username $randomText[︻デ═一;,,I got him" (҂‾ ‾)︻デ═一;killed;got killed by;died because of;failed to kill;'s bullet missed] $username[$mentioned[1]] `
})