module.exports = ({
  name: "eval",
  code: `$eval[$message]
$onlyForIDs[596296441505513483;:x: Only developer can access this command!] `
})